// Copyright 2016 Cullen Sarles All Rights Reserved.

#include "LightWeightGridPluginPCH.h"
#include "LightWeightGridInterface.h"

ULightWeightGridInterface::ULightWeightGridInterface(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{}
